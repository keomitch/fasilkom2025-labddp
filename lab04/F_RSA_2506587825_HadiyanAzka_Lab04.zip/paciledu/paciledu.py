def buka_file(filename):
    data = []
    try: # pembersihan data
        with open(filename, 'r') as file:
            next(file, None)
            for line in file:
                clean_line = line.strip()
                if not clean_line:
                    continue
                row_values = clean_line.split(",")
                data.append(row_values)
                
    except FileNotFoundError:
        print("File tidak ditemukan!")
        return []
    
    return data

def buat_laporan(datalist):
    for row in len(datalist):
        nama = str(datalist[row][0])
        nilai = round(datalist[row][1]*0.3 + datalist[row][2]*0.35 + datalist[row][3]*0.35, 2)
        
        # pemberian nilai huruf
        if 0 <= nilai < 40:
            huruf = "E"
        elif 40 <= nilai < 55:
            huruf = "D"
        elif 55 <= nilai < 70:
            huruf = "C"
        elif 70 <= nilai < 85:
            huruf = "B"
        elif 85 <= nilai < 100:
            huruf = "A"

        print(nama + " mendapatkan nilai akhir sebesar " + str(nilai) + " dan memperoleh grade " + huruf +"!")

def edit_data(nama, kolom, nilai_baru, data):
    if kolom == "tugas":
        nomor_kolom = 1
    elif kolom == "uts":
        nomor_kolom = 2
    elif kolom == "uas":
        nomor_kolom = 3

    i = 0
    while i < len(data):
        row = data[i] # Ambil row saat ini
        if row[0] == nama:
            datalist_index = i + 1
            data[datalist_index][nomor_kolom] = nilai_baru
            print("Nilai " + kolom + nama + " telah berhasil diperbarui!")
            break # Berhenti mencari setelah mengupdate cell

        i += 1 

def main():
    halt = False # penghentian program
    while halt == False:
        print("\n" + "="*5 + " PacilEdu " + "="*5)
        print("1. Buat laporan")
        print("2. Edit data")
        print("3. Keluar")
        choice = input("Pilih [1 - 3]: ").strip()

        if choice == '1':
            file = input("Masukkan nama file: ")
            data = buka_file(file)
            buat_laporan(data)
        elif choice == '2':
            file = input("Masukkan nama file: ")
            nama = input("Masukkan nama mahasiswa [perhatikan huruf besar dan kecil]: ")
            kolom = input("Masukkan nama kolom [tugas/uts/uas]: ")
            nilai_baru = input("Masukkan nilai baru untuk kolom " + kolom + ": ")
            data = buka_file(file)
            edit_data(nama, kolom, nilai_baru, data)
        elif choice == '3':
            print("\n    Otsukaresama! 🙇🏼‍\n")
            halt = True
        else:
            print("Mohon masukkan input yang valid.")

# Start the application
if __name__ == "__main__":
    main()